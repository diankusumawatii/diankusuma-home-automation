class ApiUrl {
  static const String baseUrl =
      'https://95b0-36-90-64-243.ngrok.io/toko-api/public';

  static const String registrasi = baseUrl + '/registrasi';
  static const String login = baseUrl + '/login';
}
