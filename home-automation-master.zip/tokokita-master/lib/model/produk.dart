class Produk {
  String namaProduk;
  int hargaProduk;
  String deskripsiProduk;
  String image;

  Produk({this.namaProduk, this.hargaProduk, this.deskripsiProduk, this.image});
}
